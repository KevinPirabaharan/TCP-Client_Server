#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>

#define MAXRCVLEN 500

int main(int argc, char *argv[]){

    int mysocket = 0, bytesSent, buffSize, portNum;
    if ((argc < 3) || (argc > 4))
    {
		printf("No enough/Too many arguments.\nPlease use Address Port Buffer\n");
		return 1;
	}

    if (argc == 3)
    {
        buffSize = atoi(argv[3]);
    }
    else
    {
        buffSize = MAXRCVLEN;
    }


    portNum = atoi(argv[2]);
    char buff[buffSize];

    struct sockaddr_in deset;
    mysocket = socket(AF_INET, SOCK_STREAM, 0);

    deset.sin_family = AF_INET;
    deset.sin_port = htons(portNum);
    deset.sin_addr.s_addr = inet_addr(argv[1]);

    bytesSent = connect(mysocket, (struct sockaddr *)&deset, sizeof(deset));
    if (bytesSent == bytesSent - 1)
    {
        printf("Can't connect\n");
        return 1;
    }

    FILE *fp = fopen("sample2.txt", "rb");
    if(fp == NULL)
    {
        printf("Invalid File\n");
        return 2;
    }

    int totBytesSent = 0;

    while( (bytesSent = fread(buff, 1, sizeof(buff), fp))>0 )
    {
        send(mysocket, buff, bytesSent, 0);
        totBytesSent = totBytesSent + bytesSent;
    }

    printf("Done sending! Sent %d bytes\n", totBytesSent);

    fclose(fp);
    return 0;
}
