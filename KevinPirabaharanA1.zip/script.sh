#!/bin/sh
echo "Running Clients."
echo "1:"
time ./bin/client 127.0.0.1 2300 500
echo "2:"
time ./bin/client2 127.0.0.1 2300 500
echo "3:"
time ./bin/client3 127.0.0.1 2300 500
echo "4:"
time ./bin/client4 127.0.0.1 2300 500
echo "5:"
time ./bin/client5 127.0.0.1 2300 500
echo "6:"
time ./bin/client6 127.0.0.1 2300 500
echo "Done Script"
exit 0
