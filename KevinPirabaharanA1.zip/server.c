#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>

#define MAXRCVLEN 500
int main(int argc, char *argv[]){

    int mysocket = 0, consocket = 0, bytesReceived, totalBytes, portNum;
    if (argc < 2 || argc > 2)
    {
		printf("Not enough/Too many arguments.\n");
		return 1;
	}

	portNum = atoi(argv[1]);

    struct sockaddr_in serv;

    char recvBuff[MAXRCVLEN + 1];

    mysocket = socket(AF_INET, SOCK_STREAM, 0);
    printf("Socket created\n");

    memset(&serv, '0', sizeof(serv));
    memset(recvBuff, '0', sizeof(recvBuff));

    serv.sin_family = AF_INET;
    serv.sin_addr.s_addr = inet_addr("127.0.0.1");
    serv.sin_port = htons(portNum);

    bind(mysocket, (struct sockaddr*)&serv, sizeof(serv));
    listen(mysocket, 10);

    while(1)
    {
        consocket = accept(mysocket, (struct sockaddr*)NULL, NULL);
        if (consocket==-1)
        {
            printf("Client Overload\n");
            continue;
        }

        FILE* fp = fopen( "outPut.txt", "w++");
        totalBytes = 0;
        if(fp != NULL)
        {
            while( (bytesReceived = recv(consocket, recvBuff, 1024,0))> 0 ) {
                totalBytes+=bytesReceived;
                fwrite(recvBuff, 1, bytesReceived, fp);
            }
            printf("Received byte: %d\n",totalBytes);
            if (bytesReceived<0)
            {
               printf("Receiving\n");
            }
            fclose(fp);
        }
        else
        {
            printf("Invalid File\n");
            return 1;
        }
        close(consocket);
    }
    return 0;
}
