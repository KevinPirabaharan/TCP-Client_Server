#!/bin/sh
echo "Running Clients."
echo "1:"
time ./bin/client 
echo "2:"
time ./bin/client2 
echo "3:"
time ./bin/client3
echo "4:"
time ./bin/client4
echo "5:"
time ./bin/client5
echo "6:"
time ./bin/client6
echo "Done Script"
exit 0
